/* Reliance Tracker — toolbar popup (bubble).
 * Shows connection + queue status; opens the side panel or settings.
 * No network calls here; everything is local chrome.storage reads. */
(function () {
  "use strict";

  var keyDot = document.getElementById("keyDot");
  var keyText = document.getElementById("keyText");
  var queueDot = document.getElementById("queueDot");
  var queueText = document.getElementById("queueText");

  function setDot(el, state) {
    el.className = "dot " + state;
  }

  // API key status (sync storage, same keys as options.js)
  chrome.storage.sync.get(["apiKey", "baseUrl"], function (cfg) {
    var hasKey =
      typeof cfg.apiKey === "string" && cfg.apiKey.trim().length > 8;
    if (hasKey) {
      setDot(keyDot, "ok");
      keyText.innerHTML =
        "Connected to <strong>" +
        escapeHtml(cfg.baseUrl || "humaninntheloop.com") +
        "</strong>";
    } else {
      setDot(keyDot, "bad");
      keyText.textContent = "No API key — open Settings to connect.";
    }
  });

  // Capture queue status (local storage, same shape as background.js)
  chrome.storage.local.get(["queue"], function (data) {
    var q = Array.isArray(data.queue) ? data.queue : [];
    if (q.length > 0) {
      setDot(queueDot, "ok");
      queueText.innerHTML =
        "<strong>" + q.length + "</strong> capture" +
        (q.length === 1 ? "" : "s") +
        " waiting to file";
    } else {
      setDot(queueDot, "idle");
      queueText.textContent = "No captures waiting.";
    }
  });

  document.getElementById("openTracker").addEventListener("click", function () {
    // Route through the background so the floating bubble hides/shows with
    // the panel. Falls back to the options page if the API is unavailable.
    function fallback() {
      try {
        chrome.runtime.openOptionsPage();
      } catch (e) {}
    }
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var tabId = tabs && tabs[0] && tabs[0].id;
        if (typeof tabId !== "number" || !chrome.sidePanel || !chrome.sidePanel.open) {
          fallback();
          return;
        }
        chrome.runtime.sendMessage({ type: "HITL_OPEN_PANEL", tabId: tabId }, function (res) {
          if (chrome.runtime.lastError || !res || !res.ok) fallback();
          else window.close();
        });
      });
    } catch (e) {
      fallback();
    }
  });

  document.getElementById("openSettings").addEventListener("click", function () {
    chrome.runtime.openOptionsPage();
  });

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
})();
