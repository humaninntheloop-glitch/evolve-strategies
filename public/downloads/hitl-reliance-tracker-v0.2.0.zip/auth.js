/* Shared Supabase auth for the Reliance Tracker extension.
 *
 * Lets the user sign in with their Human In The Loop platform account
 * (email + password). Filing then uses their Supabase JWT, so reliance
 * records are attributed to the actual employee instead of the admin who
 * minted a shared API key.
 *
 * The anon key below is PUBLIC by design (it ships inside the platform's
 * own web app to every visitor). Never put a service-role key here.
 */
"use strict";

var HITL_SUPABASE_URL = "https://gbqnqsoebotpoongucay.supabase.co";
var HITL_SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdicW5xc29lYm90cG9vbmd1Y2F5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU0MzgzNDQsImV4cCI6MjA5MTAxNDM0NH0.VmFhXpTlaiajktf5lg4-f1DvrWrlIZSZ1Upy9hNpYxo";

var HITL_SESSION_KEYS = [
  "hitl_sb_access",
  "hitl_sb_refresh",
  "hitl_sb_expires_at",
  "hitl_sb_email",
  "hitl_sb_user_id",
];

/** Runtime permission for the Supabase auth endpoint (asked with a user gesture). */
function hitlEnsureSupabasePermission() {
  var perms = { origins: [HITL_SUPABASE_URL + "/*"] };
  return new Promise(function (resolve) {
    chrome.permissions.contains(perms, function (has) {
      if (has) return resolve(true);
      chrome.permissions.request(perms, function (granted) {
        resolve(!!granted);
      });
    });
  });
}

function hitlGetSession() {
  return chrome.storage.local.get(HITL_SESSION_KEYS).then(function (res) {
    if (!res.hitl_sb_access) return null;
    return {
      accessToken: res.hitl_sb_access,
      refreshToken: res.hitl_sb_refresh || null,
      expiresAt: res.hitl_sb_expires_at || 0,
      email: res.hitl_sb_email || null,
      userId: res.hitl_sb_user_id || null,
    };
  });
}

function hitlSaveSession(data, email) {
  var expiresAt = Date.now() + (data.expires_in || 3600) * 1000;
  return chrome.storage.local.set({
    hitl_sb_access: data.access_token,
    hitl_sb_refresh: data.refresh_token || null,
    hitl_sb_expires_at: expiresAt,
    hitl_sb_email: email || (data.user && data.user.email) || null,
    hitl_sb_user_id: (data.user && data.user.id) || null,
  });
}

function hitlClearSession() {
  return chrome.storage.local.remove(HITL_SESSION_KEYS);
}

function hitlSupabaseTokenCall(grantType, body) {
  return fetch(HITL_SUPABASE_URL + "/auth/v1/token?grant_type=" + grantType, {
    method: "POST",
    headers: {
      apikey: HITL_SUPABASE_ANON_KEY,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  }).then(function (resp) {
    return resp
      .json()
      .catch(function () {
        return {};
      })
      .then(function (data) {
        return { ok: resp.ok, status: resp.status, data: data };
      });
  });
}

/** Sign in with platform email + password. Resolves {ok, error}. */
function hitlSignIn(email, password) {
  return hitlEnsureSupabasePermission().then(function (granted) {
    if (!granted) return { ok: false, error: "permission" };
    return hitlSupabaseTokenCall("password", { email: email, password: password }).then(
      function (r) {
        if (!r.ok || !r.data.access_token) {
          var msg =
            (r.data && (r.data.msg || r.data.error_description || r.data.error)) ||
            "Sign in failed";
          return { ok: false, error: msg };
        }
        return hitlSaveSession(r.data, email).then(function () {
          return { ok: true };
        });
      }
    );
  });
}

/** Best-effort server sign-out, then always clears local session. */
function hitlSignOut() {
  return hitlGetSession().then(function (session) {
    var remote = Promise.resolve();
    if (session && session.accessToken) {
      remote = fetch(HITL_SUPABASE_URL + "/auth/v1/logout", {
        method: "POST",
        headers: {
          apikey: HITL_SUPABASE_ANON_KEY,
          Authorization: "Bearer " + session.accessToken,
        },
      }).catch(function () {});
    }
    return remote.then(hitlClearSession);
  });
}

/** Returns a valid access token, refreshing silently when close to expiry. */
function hitlValidAccessToken() {
  return hitlGetSession().then(function (session) {
    if (!session) return null;
    // Refresh if expiring within 60s and we have a refresh token.
    if (session.refreshToken && Date.now() > session.expiresAt - 60000) {
      return hitlSupabaseTokenCall("refresh_token", {
        refresh_token: session.refreshToken,
      }).then(function (r) {
        if (!r.ok || !r.data.access_token) {
          hitlClearSession();
          return null;
        }
        return hitlSaveSession(r.data, session.email).then(function () {
          return r.data.access_token;
        });
      });
    }
    if (Date.now() > session.expiresAt) {
      hitlClearSession();
      return null;
    }
    return session.accessToken;
  });
}

/**
 * Builds the Authorization header for platform API calls.
 * Prefers the signed-in user's JWT (attributes records to them);
 * falls back to the configured API key (service use).
 * Resolves null when neither is available.
 */
function hitlAuthHeader() {
  return hitlValidAccessToken().then(function (token) {
    if (token) return { Authorization: "Bearer " + token };
    return chrome.storage.local.get(["hitl_apiKey"]).then(function (res) {
      var key = (res.hitl_apiKey || "").trim();
      if (!key) return null;
      return { Authorization: "Bearer " + key };
    });
  });
}
