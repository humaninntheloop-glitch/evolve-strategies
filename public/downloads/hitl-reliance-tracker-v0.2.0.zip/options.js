/* Human In The Loop — Reliance Tracker (options page) */
"use strict";

var DEFAULT_BASE_URL = "https://humaninntheloop.com";
var API_PATH = "/api/v1/reliance-events";

var baseUrlEl = document.getElementById("baseUrl");
var apiKeyEl = document.getElementById("apiKey");
var saveBtn = document.getElementById("save");
var testBtn = document.getElementById("test");
var resultEl = document.getElementById("result");


/* Host permission for the user-configured platform URL.
   Chrome blocks cross-origin fetch without it; the URL is user-chosen so we
   request it at runtime (user gesture) instead of declaring <all_urls>. */
function hitlOriginPattern(baseUrl) {
  try {
    return new URL(baseUrl).origin + "/*";
  } catch (e) {
    return null;
  }
}
function hitlEnsureHostPermission(baseUrl) {
  var pattern = hitlOriginPattern(baseUrl);
  if (!pattern) return Promise.resolve({ ok: false, reason: "bad-url" });
  var perms = { origins: [pattern] };
  return new Promise(function (resolve) {
    chrome.permissions.contains(perms, function (has) {
      if (has) return resolve({ ok: true });
      chrome.permissions.request(perms, function (granted) {
        resolve({ ok: !!granted });
      });
    });
  });
}

function showResult(kind, text) {
  resultEl.className = kind;
  resultEl.textContent = text;
}


/* Secrets live in chrome.storage.local (never roam via Chrome sync).
   One-time migration for settings previously saved to chrome.storage.sync. */
function migrateSecretsToLocal() {
  return chrome.storage.local.get(["hitl_baseUrl", "hitl_apiKey"]).then(function (local) {
    if (local.hitl_baseUrl || local.hitl_apiKey) return;
    return chrome.storage.sync.get(["hitl_baseUrl", "hitl_apiKey"]).then(function (synced) {
      var toSet = {};
      if (synced.hitl_baseUrl) toSet.hitl_baseUrl = synced.hitl_baseUrl;
      if (synced.hitl_apiKey) toSet.hitl_apiKey = synced.hitl_apiKey;
      if (!Object.keys(toSet).length) return;
      return chrome.storage.local.set(toSet).then(function () {
        return chrome.storage.sync.remove(["hitl_baseUrl", "hitl_apiKey"]);
      });
    });
  });
}

function normalizedBase() {
  return (baseUrlEl.value.trim() || DEFAULT_BASE_URL).replace(/\/+$/, "");
}

var showBubbleEl = document.getElementById("showBubble");
var autoOpenTypingEl = document.getElementById("autoOpenTyping");
var autoOpenResponseEl = document.getElementById("autoOpenResponse");
var bridgePanelEl = document.getElementById("bridgePanel");

function load() {
  return migrateSecretsToLocal().then(function () { return chrome.storage.local.get(["hitl_baseUrl", "hitl_apiKey", "hitl_showBubble", "hitl_autoOpen", "hitl_autoOpenTyping", "hitl_autoOpenResponse", "hitl_bridgePanel"]); }).then(function (res) {
    baseUrlEl.value = res.hitl_baseUrl || DEFAULT_BASE_URL;
    apiKeyEl.value = res.hitl_apiKey || "";
    bridgePanelEl.checked = !!res.hitl_bridgePanel;
    showBubbleEl.checked = res.hitl_showBubble !== false;
    // Migrate the legacy single toggle: both new toggles default from it
    // until the user saves Settings with the new checkboxes.
    var legacy = res.hitl_autoOpen;
    autoOpenTypingEl.checked = res.hitl_autoOpenTyping !== undefined ? !!res.hitl_autoOpenTyping : legacy !== false;
    autoOpenResponseEl.checked = res.hitl_autoOpenResponse !== undefined ? !!res.hitl_autoOpenResponse : legacy !== false;
  });
}

function save() {
  var baseUrl = normalizedBase();
  var apiKey = apiKeyEl.value.trim();
  baseUrlEl.value = baseUrl;
  var showBubble = showBubbleEl.checked;
  var autoOpenTyping = autoOpenTypingEl.checked;
  var autoOpenResponse = autoOpenResponseEl.checked;
  var bridgePanel = bridgePanelEl.checked;
  return chrome.storage.local
    .set({ hitl_baseUrl: baseUrl, hitl_apiKey: apiKey, hitl_showBubble: showBubble, hitl_autoOpenTyping: autoOpenTyping, hitl_autoOpenResponse: autoOpenResponse, hitl_bridgePanel: bridgePanel })
    .then(function () {
      showResult("info", "Settings saved.");
    });
}

/**
 * Test connection: GET the reliance-events endpoint with the key.
 * The endpoint only accepts POST, so a healthy server should answer 405
 * (or 401 for a bad key). Anything except a network failure means the
 * server is reachable — we say so honestly.
 */
function testConnection() {
  var baseUrl = normalizedBase();
  var apiKey = apiKeyEl.value.trim();
  baseUrlEl.value = baseUrl;
  saveBtn.disabled = true;
  testBtn.disabled = true;
  showResult("info", "Saving and testing…");

  var showBubble = showBubbleEl.checked;
  var autoOpenTyping = autoOpenTypingEl.checked;
  var autoOpenResponse = autoOpenResponseEl.checked;
  var bridgePanel = bridgePanelEl.checked;
  return chrome.storage.local
    .set({ hitl_baseUrl: baseUrl, hitl_apiKey: apiKey, hitl_showBubble: showBubble, hitl_autoOpenTyping: autoOpenTyping, hitl_autoOpenResponse: autoOpenResponse, hitl_bridgePanel: bridgePanel })
    .then(function () {
      return hitlEnsureHostPermission(baseUrl);
    })
    .then(function (perm) {
      if (!perm.ok) {
        showResult(
          "err",
          perm.reason === "bad-url"
            ? "That base URL doesn't look valid. Use the full https:// address of your platform."
            : "The extension needs your permission to connect to " + baseUrl + ". Click Test again and choose Allow."
        );
        return null;
      }
      return hitlAuthHeader().then(function (headers) {
        return fetch(baseUrl + API_PATH, {
          method: "GET",
          headers: headers || {},
        });
      });
    })
    .then(function (resp) {
      if (!resp) return;
      if (resp.status === 401) {
        showResult(
          "err",
          "Server reachable, but the credentials were rejected (401). Double-check the API key, or sign in again below."
        );
      } else if (resp.status === 405) {
        showResult(
          "ok",
          "Connection OK — the platform responded (405, as expected for GET on a POST-only endpoint)."
        );
      } else {
        showResult(
          "ok",
          "Server reachable — it responded with HTTP " +
            resp.status +
            ". (Any response other than a network failure means the platform is up.)"
        );
      }
    })
    .catch(function () {
      showResult(
        "err",
        "Could not reach " + baseUrl + ". Check the base URL and your network connection."
      );
    })
    .then(function () {
      saveBtn.disabled = false;
      testBtn.disabled = false;
    });
}

saveBtn.addEventListener("click", save);
testBtn.addEventListener("click", testConnection);

// ── Account sign-in ─────────────────────────────────────────────────────────
var signinEmailEl = document.getElementById("signinEmail");
var signinPasswordEl = document.getElementById("signinPassword");
var signinBtn = document.getElementById("signinBtn");
var signoutBtn = document.getElementById("signoutBtn");
var signedOutBox = document.getElementById("signedOutBox");
var signedInBox = document.getElementById("signedInBox");
var signedInEmailEl = document.getElementById("signedInEmail");
var authResultEl = document.getElementById("authResult");

function showAuthResult(kind, text) {
  authResultEl.className = kind;
  authResultEl.textContent = text;
}

function refreshAuthUI() {
  return hitlGetSession().then(function (session) {
    if (session && session.email) {
      signedOutBox.hidden = true;
      signedInBox.hidden = false;
      signedInEmailEl.textContent = session.email;
    } else {
      signedOutBox.hidden = false;
      signedInBox.hidden = true;
      signedInEmailEl.textContent = "";
    }
  });
}

signinBtn.addEventListener("click", function () {
  var email = signinEmailEl.value.trim();
  var password = signinPasswordEl.value;
  if (!email || !password) {
    showAuthResult("err", "Enter your email and password.");
    return;
  }
  signinBtn.disabled = true;
  showAuthResult("info", "Signing in…");
  hitlSignIn(email, password).then(function (r) {
    signinBtn.disabled = false;
    if (!r.ok) {
      showAuthResult(
        "err",
        r.error === "permission"
          ? "The extension needs permission to reach the sign-in service. Click Sign in again and choose Allow."
          : "Sign in failed: " + r.error
      );
      return;
    }
    signinPasswordEl.value = "";
    showAuthResult("ok", "Signed in. Filings will now be attributed to you.");
    refreshAuthUI();
  });
});

signoutBtn.addEventListener("click", function () {
  signoutBtn.disabled = true;
  hitlSignOut().then(function () {
    signoutBtn.disabled = false;
    showAuthResult("info", "Signed out.");
    refreshAuthUI();
  });
});

signinPasswordEl.addEventListener("keydown", function (e) {
  if (e.key === "Enter") signinBtn.click();
});

refreshAuthUI();

load();
