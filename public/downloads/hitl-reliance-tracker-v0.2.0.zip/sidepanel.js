
/* Host permission for the user-configured platform URL.
   Chrome blocks cross-origin fetch without it; the URL is user-chosen so we
   request it at runtime (user gesture) instead of declaring <all_urls>. */
function hitlOriginPattern(baseUrl) {
  try {
    return new URL(baseUrl).origin + "/*";
  } catch (e) {
    return null;
  }
}
function hitlEnsureHostPermission(baseUrl) {
  var pattern = hitlOriginPattern(baseUrl);
  if (!pattern) return Promise.resolve({ ok: false, reason: "bad-url" });
  var perms = { origins: [pattern] };
  return new Promise(function (resolve) {
    chrome.permissions.contains(perms, function (has) {
      if (has) return resolve({ ok: true });
      chrome.permissions.request(perms, function (granted) {
        resolve({ ok: !!granted });
      });
    });
  });
}

/* Human In The Loop — Reliance Tracker (side panel)
 *
 * Lists locally queued captures and files them as draft reliance records.
 * Network requests happen ONLY when the user clicks "File reliance event",
 * and go ONLY to the user's configured Human In The Loop base URL.
 */
"use strict";

var DEFAULT_BASE_URL = "https://humaninntheloop.com";
var API_PATH = "/api/v1/reliance-events";

var IMPACT_OPTIONS = [
  ["INTERNAL_NOTES", "Internal notes"],
  ["INTERNAL_RESEARCH", "Internal research"],
  ["INTERNAL_DOCUMENT", "Internal document"],
  ["CLIENT_COMMUNICATION", "Client communication"],
  ["EXTERNAL_REPORTS", "External reports"],
  ["FINANCIAL_LEGAL", "Financial / legal"],
  ["REGULATORY_COMPLIANCE", "Regulatory compliance"],
];

var DEFAULTS = {
  aiUsageType: "Content drafting",
  humanReviewPlan: "Manual human review",
  aiUseJustification: "Productivity and speed",
};

function el(tag, cls, text) {
  var n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

function formatBytes(n) {
  if (n == null || isNaN(n)) return "";
  if (n < 1024) return n + " B";
  if (n < 1048576) return (n / 1024).toFixed(1) + " KB";
  return (n / 1048576).toFixed(1) + " MB";
}

function splitList(s) {
  return String(s || "")
    .split(",")
    .map(function (x) {
      return x.trim();
    })
    .filter(Boolean);
}

function fmtTime(iso) {
  try {
    return new Date(iso).toLocaleString();
  } catch (e) {
    return iso || "";
  }
}

/* Secrets live in chrome.storage.local (never roam via Chrome sync).
   One-time migration for settings previously saved to chrome.storage.sync. */
function migrateSecretsToLocal() {
  return chrome.storage.local.get(["hitl_baseUrl", "hitl_apiKey"]).then(function (local) {
    if (local.hitl_baseUrl || local.hitl_apiKey) return;
    return chrome.storage.sync.get(["hitl_baseUrl", "hitl_apiKey"]).then(function (synced) {
      var toSet = {};
      if (synced.hitl_baseUrl) toSet.hitl_baseUrl = synced.hitl_baseUrl;
      if (synced.hitl_apiKey) toSet.hitl_apiKey = synced.hitl_apiKey;
      if (!Object.keys(toSet).length) return;
      return chrome.storage.local.set(toSet).then(function () {
        return chrome.storage.sync.remove(["hitl_baseUrl", "hitl_apiKey"]);
      });
    });
  });
}

function getSettings() {
  return migrateSecretsToLocal().then(function () {
    return chrome.storage.local.get(["hitl_baseUrl", "hitl_apiKey"]);
  }).then(function (res) {
    return {
      baseUrl: (res.hitl_baseUrl || DEFAULT_BASE_URL).replace(/\/+$/, ""),
      apiKey: res.hitl_apiKey || "",
    };
  });
}

function getQueue() {
  return chrome.storage.local.get(["hitl_queue"]).then(function (res) {
    return Array.isArray(res.hitl_queue) ? res.hitl_queue : [];
  });
}

function showStatus(kind, html) {
  var box = document.getElementById("status");
  box.innerHTML = "";
  if (!kind) return;
  var n = el("div", "notice " + kind);
  n.innerHTML = html;
  box.appendChild(n);
}

function openOptions(e) {
  if (e) e.preventDefault();
  chrome.runtime.openOptionsPage();
}

function fileCapture(item, form, btn) {
  btn.disabled = true;
  var original = btn.textContent;
  btn.textContent = "Filing…";

  return Promise.all([getSettings(), hitlAuthHeader()]).then(function (res) {
    var settings = res[0];
    var authHeader = res[1];
    if (!authHeader) {
      showStatus("warn", "Not connected. <a href=\"#\" id=\"statusOptions\">Sign in or add an API key in settings</a> to file.");
      document.getElementById("statusOptions").addEventListener("click", openOptions);
      btn.disabled = false;
      btn.textContent = original;
      return;
    }

    var body = {
      submit: !!form.submitNow.checked,
      aiToolUsed: splitList(form.tool.value),
      aiOutputImpact: form.impact.value,
      dataSensitivity: form.sensitive.checked,
      aiUsageType: splitList(form.usage.value),
      humanReviewPlan: splitList(form.review.value),
      aiUseJustification: splitList(form.justify.value),
      intendedUseDescription: form.intended.value.trim() || undefined,
      // Same summary composition as the desktop panel: the prompt files as a
      // labeled section ahead of the output, capped at the API max (20,000).
      aiSummary:
        (item.prompt
          ? "Prompt:\n" + item.prompt + "\n\nAI output:\n" + item.output
          : item.output
        ).slice(0, 20000) || undefined,
      sourceUrl: item.url || undefined,
      capturedAt: item.capturedAt || undefined,
    };
    var other = form.toolOther.value.trim();
    if (other) body.aiToolUsedOther = other;
    if (item.attachments && item.attachments.length) {
      body.attachments = item.attachments.map(function (a) {
        return { name: a.name, sizeBytes: a.size, mimeType: a.type };
      });
    }
    Object.keys(body).forEach(function (k) {
      if (body[k] === undefined) delete body[k];
    });

    return hitlEnsureHostPermission(settings.baseUrl).then(function (perm) {
      if (!perm.ok) {
        showStatus(
          "err",
          perm.reason === "bad-url"
            ? "The platform URL in settings doesn't look valid. <a href=\"#\" id=\"statusOptions\">Open settings</a> to fix it."
            : "The extension needs permission to reach your platform. File again and choose Allow when Chrome asks."
        );
        var link = document.getElementById("statusOptions");
        if (link) link.addEventListener("click", openOptions);
        btn.disabled = false;
        btn.textContent = original;
        return null;
      }
      var headers = { "Content-Type": "application/json" };
      headers.Authorization = authHeader.Authorization;
      return fetch(settings.baseUrl + API_PATH, {
      method: "POST",
      headers: headers,
      body: JSON.stringify(body),
    })
      .then(function (resp) {
        return resp
          .json()
          .catch(function () {
            return {};
          })
          .then(function (data) {
            return { resp: resp, data: data };
          });
      })
      .then(function (r) {
        var status = r.resp.status;
        if (status === 201) {
          var recordStatus = r.data.status || "DRAFT";
          var doneMsg =
            recordStatus === "RECORDED"
              ? "Filed, auto-approved (low risk) and recorded."
              : recordStatus === "SUBMITTED"
                ? "Filed and submitted for review."
                : "Filed as draft.";
          var recordUrl = settings.baseUrl + (r.data.url || "/permission-slips/" + r.data.id);
          var link = escapeHtml(recordUrl);
          showStatus(
            "ok",
            doneMsg + " Opening it for review. " +
              '<a class="filed-link" href="' + link + '" target="_blank" rel="noopener">Open the record</a>'
          );
          // Take the user straight to the draft record so they can review
          // and submit it. chrome.tabs.create needs no user gesture.
          try {
            chrome.tabs.create({ url: recordUrl });
          } catch (e) {
            /* tab open blocked — the link above remains */
          }
          return chrome.runtime
            .sendMessage({ type: "HITL_REMOVE", id: item.id })
            .then(render);
        }
        if (status === 401) {
          // If we filed with a signed-in session, its token is dead — clear it.
          hitlGetSession().then(function (session) {
            if (session && session.accessToken) hitlClearSession().then(render);
          });
          showStatus(
            "err",
            "Credentials rejected (401). <a href=\"#\" id=\"statusOptions\">Sign in again or check the API key in settings</a>."
          );
          document.getElementById("statusOptions").addEventListener("click", openOptions);
          return;
        }
        if (status === 422) {
          var issues = r.data.issues || r.data.error || "validation failed";
          showStatus("err", "The platform rejected this record (422): " + escapeHtml(String(issues)));
          return;
        }
        if (status === 429) {
          showStatus("err", "Rate limited by the platform (429). Wait a bit and try again.");
          return;
        }
        showStatus("err", "Unexpected response (" + status + "). Please try again.");
      })
      .catch(function (err) {
        showStatus(
          "err",
          "Could not reach " + escapeHtml(settings.baseUrl) + ". Check the base URL in settings and your connection."
        );
      })
      .then(function (r) {
        if (r === null) return null;
        return r;
      })
      .then(function () {
        btn.disabled = false;
        btn.textContent = original;
      });
    });
  });
}

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
}

function renderItem(item) {
  var card = el("div", "card");

  var meta = el("div", "meta");
  var strong = el("strong", null, item.tool);
  meta.appendChild(strong);
  if (item.fallback) {
    var tag = el("span", "fallback-tag", "best-effort capture");
    meta.appendChild(tag);
  }
  meta.appendChild(document.createTextNode(" · " + fmtTime(item.capturedAt)));
  if (item.url) {
    meta.appendChild(document.createElement("br"));
    var link = el("a", null, item.url.length > 60 ? item.url.slice(0, 60) + "…" : item.url);
    link.href = item.url;
    link.target = "_blank";
    link.rel = "noopener";
    meta.appendChild(link);
  }
  card.appendChild(meta);

  if (item.attachments && item.attachments.length) {
    var attLine = el(
      "div",
      "meta",
      "Attached: " +
        item.attachments
          .map(function (a) {
            var size = formatBytes(a.size);
            return a.name + (size ? " (" + size + ")" : "");
          })
          .join(", ")
    );
    card.appendChild(attLine);
  }

  if (item.prompt) {
    var pLabel = el("div", "meta", "Your prompt:");
    card.appendChild(pLabel);
    card.appendChild(
      el("div", "preview", item.prompt.slice(0, 600) + (item.prompt.length > 600 ? "…" : ""))
    );
  }
  var oLabel = el("div", "meta", item.origin === "copy" ? "Copied text:" : "AI response:");
  card.appendChild(oLabel);
  card.appendChild(
    el("div", "preview", item.output.slice(0, 600) + (item.output.length > 600 ? "…" : ""))
  );

  var form = {};
  function field(labelText, input) {
    card.appendChild(el("label", null, labelText));
    card.appendChild(input);
    return input;
  }

  form.tool = field("AI tool(s), comma-separated", el("input"));
  form.tool.type = "text";
  form.tool.value = item.tool || "";

  var otherInput = el("input");
  otherInput.type = "text";
  otherInput.placeholder = "Other tool name (only if you add OTHER above)";
  field("Other tool (optional)", otherInput);
  form.toolOther = otherInput;

  var impactSel = el("select");
  IMPACT_OPTIONS.forEach(function (opt) {
    var o = document.createElement("option");
    o.value = opt[0];
    o.textContent = opt[1];
    impactSel.appendChild(o);
  });
  impactSel.value = "INTERNAL_NOTES";
  field("AI output impact", impactSel);
  form.impact = impactSel;

  var sensRow = el("div", "row");
  var sensBox = el("input");
  sensBox.type = "checkbox";
  var sensLabel = el("label", null, "Contains sensitive data");
  sensRow.appendChild(sensBox);
  sensRow.appendChild(sensLabel);
  card.appendChild(el("label", null, "Data sensitivity"));
  card.appendChild(sensRow);
  form.sensitive = sensBox;

  form.usage = field("AI reliance type(s), comma-separated", el("input"));
  form.usage.type = "text";
  form.usage.value = DEFAULTS.aiUsageType;

  form.review = field("Human review plan(s), comma-separated", el("input"));
  form.review.type = "text";
  form.review.value = DEFAULTS.humanReviewPlan;

  form.justify = field("Justification(s) for AI use, comma-separated", el("input"));
  form.justify.type = "text";
  form.justify.value = DEFAULTS.aiUseJustification;

  var intended = el("textarea");
  intended.value = "";
  intended.placeholder = "What will this AI output be used for?";
  field("Intended use (editable)", intended);
  form.intended = intended;

  var det = el("details");
  var sum = el("summary", null, "Full captured output");
  det.appendChild(sum);
  det.appendChild(el("div", "preview", item.output));
  card.appendChild(det);

  var submitRow = el("div", "row");
  var submitBox = el("input");
  submitBox.type = "checkbox";
  submitBox.checked = false;
  var submitLabel = el("label", null, "Submit for review immediately (skip draft)");
  submitRow.appendChild(submitBox);
  submitRow.appendChild(submitLabel);
  card.appendChild(submitRow);
  form.submitNow = submitBox;

  var fileBtn = el("button", "primary", "File reliance event");
  fileBtn.addEventListener("click", function () {
    fileCapture(item, form, fileBtn);
  });
  card.appendChild(fileBtn);

  var discard = el("button", "danger", "Discard");
  discard.addEventListener("click", function () {
    chrome.runtime.sendMessage({ type: "HITL_REMOVE", id: item.id }).then(render);
  });
  card.appendChild(discard);

  return card;
}

function render() {
  showStatus(null);
  return Promise.all([getSettings(), getQueue(), hitlGetSession()]).then(function (res) {
    var settings = res[0];
    var queue = res[1];
    var session = res[2];

    document.getElementById("keyNotice").hidden = !!(
      settings.apiKey ||
      (session && session.accessToken)
    );
    document.getElementById("count").textContent =
      queue.length === 1 ? "1 capture queued" : queue.length + " captures queued";
    document.getElementById("clearAll").hidden = queue.length === 0;
    document.getElementById("empty").hidden = queue.length !== 0;

    var list = document.getElementById("list");
    list.innerHTML = "";
    queue.forEach(function (item) {
      list.appendChild(renderItem(item));
    });
  });
}

/* Keep a port open for the panel's lifetime so the background can detect
 * when the panel closes (port disconnect) and re-show the floating bubble. */
var hitlLifetimePort = null;
try {
  hitlLifetimePort = chrome.runtime.connect({ name: "hitl-panel-lifetime" });
} catch (e) {
  /* ignore */
}
window.addEventListener("pagehide", function () {
  try {
    chrome.runtime.sendMessage({ type: "HITL_PANEL_CLOSED" });
  } catch (e) {
    /* page unloading — ignore */
  }
});

document.getElementById("openOptions").addEventListener("click", openOptions);
document.getElementById("clearAll").addEventListener("click", function () {
  chrome.runtime.sendMessage({ type: "HITL_CLEAR" }).then(render);
});

chrome.storage.onChanged.addListener(function (changes, area) {
  if (area === "local" && (changes.hitl_queue || changes.hitl_apiKey || changes.hitl_baseUrl)) render();
});

render();
