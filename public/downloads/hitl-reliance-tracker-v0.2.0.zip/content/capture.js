/* Human In The Loop — Reliance Tracker (content script)
 *
 * Runs on AI-tool pages. Watches the conversation DOM and reports
 * {tool, prompt, output, url, capturedAt, attachments} snapshots to the
 * background service worker, which stores them LOCALLY in chrome.storage.local.
 * attachments is file metadata only (name/size/type) — never file contents.
 *
 * Nothing leaves the browser from this script. Data is only transmitted
 * to the user's Human In The Loop platform when the user explicitly
 * clicks "File reliance event" in the side panel.
 */
(function () {
  "use strict";

  var MAX_PROMPT_CHARS = 2000;
  var MAX_OUTPUT_CHARS = 8000;

  var site = hitlResolveSite(location.hostname);
  if (!site) return; // unknown host — do nothing

  function truncate(s, max) {
    if (!s) return "";
    s = String(s).trim().replace(/\s+\n/g, "\n");
    return s.length > max ? s.slice(0, max) + "…" : s;
  }

  function textOf(el) {
    return (el && el.innerText ? el.innerText : "").trim();
  }

  /** First selector in the list that matches non-empty nodes. */
  function queryFirst(selectors) {
    for (var i = 0; i < selectors.length; i++) {
      try {
        var nodes = document.querySelectorAll(selectors[i]);
        if (nodes && nodes.length) {
          var list = Array.prototype.slice.call(nodes).filter(function (n) {
            return textOf(n).length > 0;
          });
          // Skip selectors whose matches are all empty (stale markup) —
          // otherwise an empty match would "win" and yield blank captures.
          if (list.length) return list;
        }
      } catch (e) {
        /* invalid selector — try next */
      }
    }
    return [];
  }

  /**
   * Generic fallback when site markup is unknown: find the largest
   * non-nested text blocks on the page and treat the last two as the
   * most recent prompt/response pair.
   */
  function fallbackPair() {
    var candidates = [];
    var walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_ELEMENT,
      {
        acceptNode: function (node) {
          var tag = node.tagName;
          if (
            tag === "SCRIPT" ||
            tag === "STYLE" ||
            tag === "NOSCRIPT" ||
            tag === "TEXTAREA" ||
            tag === "INPUT"
          ) {
            return NodeFilter.FILTER_REJECT;
          }
          var t = textOf(node);
          if (t.length < 120) return NodeFilter.FILTER_SKIP;
          // Skip nodes whose children already carry most of the text
          // (keeps the outermost block only).
          return NodeFilter.FILTER_ACCEPT;
        },
      }
    );
    var node;
    while ((node = walker.nextNode())) {
      candidates.push(node);
    }
    // Drop blocks fully contained in a later block's text to reduce nesting.
    var texts = candidates.map(textOf).filter(function (t, i, arr) {
      return arr.indexOf(t) === i;
    });
    if (texts.length < 2) return null;
    return {
      prompt: texts[texts.length - 2],
      output: texts[texts.length - 1],
      fallback: true,
    };
  }

  function latestPair() {
    var users = queryFirst(site.userSelectors);
    var ais = queryFirst(site.aiSelectors);
    if (users.length && ais.length) {
      var promptEl = users[users.length - 1];
      var outputEl = ais[ais.length - 1];
      return {
        prompt: textOf(promptEl),
        output: textOf(outputEl),
        promptEl: promptEl,
        outputEl: outputEl,
        fallback: false,
      };
    }
    var fb = fallbackPair();
    return fb
      ? { prompt: fb.prompt, output: fb.output, promptEl: null, outputEl: null, fallback: true }
      : null;
  }


  /* Login / signup / paywall pages are never worth capturing. The fallback
   * heuristic would otherwise queue their boilerplate ("Continue with
   * Google", "Create account", ...). Require 2+ signals to avoid dropping
   * legitimate conversations that merely mention logging in. */
  var LOGIN_PATTERNS = [
    /log\s*in or sign\s*up/i,
    /continue with google/i,
    /continue with microsoft/i,
    /create account/i,
    /welcome back/i,
    /enter your phone number/i,
  ];

  function looksLikeLoginPage(text) {
    if (!text) return false;
    var hits = 0;
    for (var i = 0; i < LOGIN_PATTERNS.length; i++) {
      if (LOGIN_PATTERNS[i].test(text)) hits++;
    }
    return hits >= 2;
  }


  /* ---- Attachment detection ----
   * Catches files the user adds to the prompt via the attach button
   * (<input type=file>), drag-and-drop, or paste. Metadata only — file
   * names, sizes and MIME types are recorded; file contents are NEVER read.
   * Pending attachments are consumed by the next captured send and expire
   * after 10 minutes, so a file attached-but-never-sent can't leak into a
   * later, unrelated capture. */
  var hitlPendingAttachments = [];
  var HITL_ATTACHMENT_TTL_MS = 10 * 60 * 1000;

  function hitlNoteFiles(fileList) {
    if (!fileList || !fileList.length) return;
    var now = Date.now();
    for (var i = 0; i < fileList.length; i++) {
      var f = fileList[i];
      var entry = {
        name: f.name || "unnamed file",
        size: typeof f.size === "number" ? f.size : null,
        type: f.type || null,
        addedAt: now,
      };
      var dup = hitlPendingAttachments.some(function (a) {
        return a.name === entry.name && a.size === entry.size;
      });
      if (!dup) hitlPendingAttachments.push(entry);
    }
  }

  function hitlConsumeAttachments() {
    var now = Date.now();
    var fresh = hitlPendingAttachments.filter(function (a) {
      return now - a.addedAt < HITL_ATTACHMENT_TTL_MS;
    });
    hitlPendingAttachments = [];
    return fresh.map(function (a) {
      return { name: a.name, size: a.size, type: a.type };
    });
  }

  document.addEventListener(
    "change",
    function (e) {
      var t = e.target;
      if (t && t.tagName === "INPUT" && t.type === "file" && t.files) {
        hitlNoteFiles(t.files);
      }
    },
    true
  );

  document.addEventListener(
    "drop",
    function (e) {
      if (e.dataTransfer && e.dataTransfer.files) {
        hitlNoteFiles(e.dataTransfer.files);
      }
    },
    true
  );

  document.addEventListener(
    "paste",
    function (e) {
      var cd = e.clipboardData;
      if (cd && cd.files) hitlNoteFiles(cd.files);
    },
    true
  );

  /* ---- Auto-open triggers ----
   * 1. Typing starts: first focus/input in the prompt composer per page load.
   *    A real keypress counts as a user gesture, so the panel may open.
   * 2. Response processed: a NEW prompt/response pair settles (not the page's
   *    initial state). No gesture exists here, so Chrome may refuse — the
   *    call fails silently and the bubble pulses + its red dot covers it.
   * The background only opens when the panel isn't already open. The response
   * trigger re-arms whenever the panel closes (HITL_REARM_AUTOOPEN), so every
   * new response in a conversation can pop the panel — not just the first.
   * Each trigger has its own Settings toggle (hitl_autoOpenTyping /
   * hitl_autoOpenResponse); the legacy hitl_autoOpen key is honored as the
   * default for both until the user saves Settings. */
  var hitlAutoOpened = { typing: false, response: false };
  var hitlSeenFirstPair = false;
  var hitlLastPairKey = null;

  function hitlRequestAutoOpen(kind) {
    var key = kind === "typing" ? "hitl_autoOpenTyping" : "hitl_autoOpenResponse";
    chrome.storage.local.get([key, "hitl_autoOpen"]).then(function (res) {
      var enabled = res[key] !== undefined ? res[key] : res.hitl_autoOpen;
      if (enabled === false) return; // user disabled this trigger
      try {
        chrome.runtime.sendMessage({ type: "HITL_AUTO_OPEN" });
      } catch (e) {}
    });
  }

  function hitlUserTypingNow() {
    var a = document.activeElement;
    return !!(
      a &&
      (a.tagName === "TEXTAREA" || a.getAttribute("contenteditable") === "true")
    );
  }

  // The background re-arms us when the panel closes, so the next new
  // response can trigger again.
  try {
    chrome.runtime.onMessage.addListener(function (message) {
      if (message && message.type === "HITL_REARM_AUTOOPEN") {
        hitlAutoOpened.response = false;
      }
    });
  } catch (e) {}

  function hitlPairKey(pair) {
    return (pair.prompt || "").slice(0, 80) + "\u27e6" + (pair.output || "").slice(0, 80);
  }

  function hitlNotePairForAutoOpen(pair) {
    var key = hitlPairKey(pair);
    if (!hitlSeenFirstPair) {
      hitlSeenFirstPair = true;
      hitlLastPairKey = key;
      return;
    }
    if (
      key !== hitlLastPairKey &&
      !hitlAutoOpened.response &&
      pair.prompt &&
      pair.output
    ) {
      hitlAutoOpened.response = true;
      // Don't pop the panel over the user's active typing — the queue's red
      // dot already signals the new capture; the trigger re-arms on close.
      if (!hitlUserTypingNow()) hitlRequestAutoOpen("response");
    }
    hitlLastPairKey = key;
  }

  document.addEventListener(
    "focusin",
    function (e) {
      if (hitlAutoOpened.typing) return;
      var t = e.target;
      if (
        t &&
        (t.tagName === "TEXTAREA" || t.getAttribute("contenteditable") === "true")
      ) {
        hitlAutoOpened.typing = true;
        hitlRequestAutoOpen("typing");
      }
    },
    true
  );

  function sendCapture(pair, origin) {
    if (!pair || !pair.output) return;
    if (looksLikeLoginPage((pair.prompt || "") + "\n" + pair.output)) return; // login wall — skip
    // Attachments belong to a send: only consume them when this pair is new
    // relative to the last one seen (page-load snapshots must not grab them).
    var isNewPair = hitlSeenFirstPair && hitlPairKey(pair) !== hitlLastPairKey;
    hitlNotePairForAutoOpen(pair);
    var capture = {
      tool: site.tool,
      prompt: truncate(pair.prompt, MAX_PROMPT_CHARS),
      output: truncate(pair.output, MAX_OUTPUT_CHARS),
      url: location.href.split("#")[0],
      capturedAt: new Date().toISOString(),
      origin: origin,
      fallback: !!pair.fallback,
      attachments: isNewPair ? hitlConsumeAttachments() : [],
    };
    try {
      chrome.runtime.sendMessage({ type: "HITL_CAPTURE", capture: capture });
    } catch (e) {
      /* extension context invalidated — ignore */
    }
  }

  function snapshot() {
    sendCapture(latestPair(), "snapshot");
  }

  // --- Snapshot on load + on DOM settle (new messages streaming in) ---
  var settleTimer = null;
  function scheduleSnapshot() {
    if (settleTimer) clearTimeout(settleTimer);
    settleTimer = setTimeout(snapshot, 2500);
  }

  setTimeout(snapshot, 2000);
  try {
    var observer = new MutationObserver(scheduleSnapshot);
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  } catch (e) {
    /* observer unavailable — load-time snapshot still sent */
  }

  // --- Copy events inside AI response regions ---
  document.addEventListener("copy", function () {
    var selection = window.getSelection ? window.getSelection().toString() : "";
    if (!selection || selection.trim().length < 20) return;

    var anchor = window.getSelection().anchorNode;
    var anchorEl = anchor && anchor.nodeType === 3 ? anchor.parentElement : anchor;
    if (!anchorEl || !anchorEl.closest) return;

    var inAiRegion = site.aiSelectors.some(function (sel) {
      try {
        return !!anchorEl.closest(sel);
      } catch (e) {
        return false;
      }
    });
    if (!inAiRegion && !document.body.contains(anchorEl)) return;
    if (!inAiRegion) {
      // Copy outside a recognized AI region — still record it as a
      // best-effort capture, marked as fallback.
      var fb = fallbackPair();
      sendCapture(
        { prompt: fb ? fb.prompt : "", output: selection, fallback: true },
        "copy"
      );
      return;
    }

    // Find the nearest preceding user prompt for context.
    var users = queryFirst(site.userSelectors);
    var promptText = "";
    if (users.length) {
      for (var i = users.length - 1; i >= 0; i--) {
        var rel = anchorEl.compareDocumentPosition(users[i]);
        if (rel & Node.DOCUMENT_POSITION_PRECEDING) {
          promptText = textOf(users[i]);
          break;
        }
      }
      if (!promptText) promptText = textOf(users[users.length - 1]);
    }
    sendCapture({ prompt: promptText, output: selection, fallback: false }, "copy");
  });
})();
