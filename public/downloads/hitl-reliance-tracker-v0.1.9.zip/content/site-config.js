/* Human In The Loop — Reliance Tracker
 * Per-site DOM adapters. Each entry maps a hostname pattern to the selectors
 * used to find user prompts and AI responses on that site.
 *
 * Keep this file as the single place to update when sites change their markup.
 * Every adapter degrades gracefully: if none of the listed selectors match,
 * capture.js falls back to a generic "largest text blocks" heuristic.
 *
 * Selector strategy: ordered fallback chains — the first selector matching
 * non-empty nodes wins (see queryFirst in capture.js). Site-specific
 * selectors come first; additional fallback selectors were adapted from the
 * MIT-licensed Couchraver/claude-chatgpt-gemini-downloader repo, which
 * maintains battle-tested selector chains for these sites.
 */

const HITL_SITES = [
  {
    id: "chatgpt",
    tool: "ChatGPT",
    hostPatterns: ["chat.openai.com", "chatgpt.com"],
    // ChatGPT marks turns with data-message-author-role="user" | "assistant"
    userSelectors: [
      '[data-message-author-role="user"]',
      '[data-testid^="conversation-turn"] [data-message-author-role="user"]',
      '[data-testid*="conversation-turn"] [data-message-author-role="user"]',
    ],
    aiSelectors: [
      '[data-message-author-role="assistant"]',
      '[data-testid^="conversation-turn"] [data-message-author-role="assistant"]',
      '[data-testid*="conversation-turn"] [data-message-author-role="assistant"]',
      ".markdown",
    ],
  },
  {
    id: "claude",
    tool: "Claude",
    hostPatterns: ["claude.ai"],
    userSelectors: [
      '[data-testid="user-message"]',
      '[data-testid*="user-message"]',
      '[data-test-render-count] [class*="user"]',
      '.font-user-message',
    ],
    aiSelectors: [
      '[data-testid="ai-message"]',
      '[data-testid*="ai-message"]',
      ".font-claude-message",
      ".claude-response",
      '[class*="assistant-message"]',
    ],
  },
  {
    id: "gemini",
    tool: "Gemini",
    hostPatterns: ["gemini.google.com"],
    userSelectors: [
      "user-query",
      ".user-query",
      ".query-text",
      '[data-test-id="user-query"]',
    ],
    aiSelectors: [
      "model-response",
      ".model-response-text",
      '[data-test-id="model-response"]',
      ".message-content",
      ".response-container",
      ".conversation-turn",
    ],
  },
  {
    id: "copilot",
    tool: "Copilot",
    hostPatterns: ["copilot.microsoft.com"],
    userSelectors: [
      '[data-content="user"]',
      ".user-message",
      '[aria-label="User message"]',
    ],
    aiSelectors: [
      '[data-content="ai"]',
      ".ai-message",
      '[aria-label="AI message"]',
    ],
  },
  {
    id: "perplexity",
    tool: "Perplexity",
    hostPatterns: ["www.perplexity.ai", "perplexity.ai"],
    userSelectors: [
      '[class*="user-query"]',
      '[data-testid="query"]',
    ],
    aiSelectors: [
      '[class*="answer"]',
      '[data-testid="answer"]',
      ".prose",
    ],
  },
];

/**
 * Resolve the adapter for the current page, or null if this host is unknown.
 */
function hitlResolveSite(hostname) {
  const host = hostname.toLowerCase();
  for (const site of HITL_SITES) {
    if (site.hostPatterns.some((p) => host === p || host.endsWith("." + p))) {
      return site;
    }
  }
  return null;
}
