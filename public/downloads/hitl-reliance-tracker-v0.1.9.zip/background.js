/* Human In The Loop — Reliance Tracker (service worker)
 *
 * Receives captures from content scripts, dedupes them, and keeps a local
 * queue in chrome.storage.local. Shows the queue size as a toolbar badge.
 *
 * This worker performs NO network requests. Data leaves the browser only
 * when the user clicks "File reliance event" in the side panel.
 */
"use strict";

var QUEUE_KEY = "hitl_queue";
var SEEN_KEY = "hitl_seen_hashes";
var MAX_QUEUE = 50;
var MAX_SEEN = 300;

/** Tiny non-crypto hash for dedupe. */
function hashCapture(c) {
  var attNames = Array.isArray(c.attachments)
    ? c.attachments.map(function (a) { return a.name || ""; }).join(",")
    : "";
  var s = [c.tool, c.prompt, c.output, c.url, attNames].join("\u0000");
  var h1 = 0x811c9dc5;
  for (var i = 0; i < s.length; i++) {
    h1 ^= s.charCodeAt(i);
    h1 = Math.imul(h1, 0x01000193) >>> 0;
  }
  return h1.toString(16);
}

function getState() {
  return chrome.storage.local
    .get([QUEUE_KEY, SEEN_KEY])
    .then(function (res) {
      return {
        queue: Array.isArray(res[QUEUE_KEY]) ? res[QUEUE_KEY] : [],
        seen: Array.isArray(res[SEEN_KEY]) ? res[SEEN_KEY] : [],
      };
    });
}

function updateBadge(count) {
  var text = count > 0 ? String(Math.min(count, 99)) : "";
  return chrome.action
    .setBadgeText({ text: text })
    .then(function () {
      return chrome.action.setBadgeBackgroundColor({ color: "#4f46e5" });
    })
    .catch(function () {
      /* badge unsupported — ignore */
    });
}

function addCapture(capture) {
  var hash = hashCapture(capture);
  return getState().then(function (state) {
    if (state.seen.indexOf(hash) !== -1) return state.queue.length; // duplicate
    var item = {
      id: "q_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8),
      tool: capture.tool || "Unknown",
      prompt: capture.prompt || "",
      output: capture.output || "",
      url: capture.url || "",
      capturedAt: capture.capturedAt || new Date().toISOString(),
      origin: capture.origin || "snapshot",
      fallback: !!capture.fallback,
      attachments: Array.isArray(capture.attachments) ? capture.attachments.slice(0, 10) : [],
      hash: hash,
    };
    var queue = [item].concat(state.queue).slice(0, MAX_QUEUE);
    var seen = [hash].concat(state.seen).slice(0, MAX_SEEN);
    return chrome.storage.local
      .set({ hitl_queue: queue, hitl_seen_hashes: seen })
      .then(function () {
        return updateBadge(queue.length).then(function () {
          return queue.length;
        });
      });
  });
}

function removeFromQueue(id) {
  return getState().then(function (state) {
    var queue = state.queue.filter(function (item) {
      return item.id !== id;
    });
    return chrome.storage.local
      .set({ hitl_queue: queue })
      .then(function () {
        return updateBadge(queue.length);
      });
  });
}

function clearQueue() {
  return chrome.storage.local
    .set({ hitl_queue: [] })
    .then(function () {
      return updateBadge(0);
    });
}

/* ---- Side-panel visibility tracking (drives the floating bubble) ----
 * The bubble hides while the panel is open and returns when it closes.
 * The panel page holds a "hitl-panel-lifetime" port open; its disconnect
 * (plus a pagehide message backup) tells us the panel closed. */
var hitlPanelOpenTabs = {}; // tabId -> true

function hitlNotifyBubble(tabId, open) {
  try {
    var p = chrome.tabs.sendMessage(Number(tabId), {
      type: "HITL_PANEL_STATE",
      open: !!open,
    });
    if (p && p.catch) p.catch(function () {});
  } catch (e) {
    /* no content script in that tab — ignore */
  }
}

function hitlPanelOpened(tabId) {
  if (typeof tabId !== "number") return;
  hitlPanelOpenTabs[tabId] = true;
  hitlNotifyBubble(tabId, true);
}

function hitlPanelClosed() {
  Object.keys(hitlPanelOpenTabs).forEach(function (id) {
    hitlNotifyBubble(id, false);
  });
  hitlPanelOpenTabs = {};
}

chrome.runtime.onConnect.addListener(function (port) {
  if (!port || port.name !== "hitl-panel-lifetime") return;
  var tabId = port.sender && port.sender.tab && port.sender.tab.id;
  port.onDisconnect.addListener(function () {
    if (typeof tabId === "number") {
      delete hitlPanelOpenTabs[tabId];
      hitlNotifyBubble(tabId, false);
      // Re-arm the response auto-open: the next new AI response in this tab
      // may pop the panel again.
      try {
        var rp = chrome.tabs.sendMessage(Number(tabId), { type: "HITL_REARM_AUTOOPEN" });
        if (rp && rp.catch) rp.catch(function () {});
      } catch (e) {
        /* no content script in that tab — ignore */
      }
    } else {
      hitlPanelClosed(); // tab unknown — clear everything we recorded
    }
  });
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {  if (!message || typeof message.type !== "string") return false;

  if (message.type === "HITL_CAPTURE" && message.capture) {
    addCapture(message.capture).then(
      function () {
        sendResponse({ ok: true });
      },
      function () {
        sendResponse({ ok: false });
      }
    );
    return true; // async response
  }

  if (message.type === "HITL_REMOVE" && message.id) {
    removeFromQueue(message.id).then(function () {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.type === "HITL_CLEAR") {
    clearQueue().then(function () {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.type === "HITL_OPEN_PANEL") {
    var tabId =
      (sender && sender.tab && sender.tab.id) != null
        ? sender.tab.id
        : message.tabId;
    if (typeof tabId === "number" && chrome.sidePanel && chrome.sidePanel.open) {
      chrome.sidePanel.open({ tabId: tabId }).then(
        function () {
          hitlPanelOpened(tabId);
          sendResponse({ ok: true });
        },
        function () {
          hitlNotifyBubble(tabId, false); // open failed — re-show the bubble
          sendResponse({ ok: false });
        }
      );
    } else {
      sendResponse({ ok: false });
    }
    return true;
  }

  if (message.type === "HITL_PANEL_CLOSED") {
    hitlPanelClosed();
    sendResponse({ ok: true });
    return true;
  }

  /* Best-effort auto-open (typing started / new response settled). Only the
   * typing trigger carries a real user gesture; Chrome refuses the rest.
   * Never opens twice, never interrupts an open panel. When Chrome refuses,
   * the tab is told so it can pulse the floating bubble instead. */
  if (message.type === "HITL_AUTO_OPEN") {
    var autoTabId = sender && sender.tab && sender.tab.id;
    if (
      typeof autoTabId === "number" &&
      !hitlPanelOpenTabs[autoTabId] &&
      chrome.sidePanel &&
      chrome.sidePanel.open
    ) {
      chrome.sidePanel.open({ tabId: autoTabId }).then(
        function () {
          hitlPanelOpened(autoTabId);
        },
        function () {
          /* no gesture / denied — pulse the bubble so the user still notices */
          try {
            var bp = chrome.tabs.sendMessage(Number(autoTabId), {
              type: "HITL_AUTO_OPEN_BLOCKED",
            });
            if (bp && bp.catch) bp.catch(function () {});
          } catch (e) {
            /* no content script in that tab — ignore */
          }
        }
      );
    }
    return false;
  }

  return false;
});

// Open the side panel when the toolbar icon is clicked.
try {
  chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch(function () {});
} catch (e) {
  /* sidePanel API unavailable — ignore */
}

// Restore badge on startup / install.
chrome.runtime.onStartup.addListener(function () {
  getState().then(function (state) {
    updateBadge(state.queue.length);
  });
});
chrome.runtime.onInstalled.addListener(function () {
  getState().then(function (state) {
    updateBadge(state.queue.length);
  });
});
